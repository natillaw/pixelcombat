========================================================================
THANK YOU FOR DOWNLOADING!
* Rate this pack (it takes 3 clicks and helps a lot):
  https://willosuna.itch.io/magic-spells-vfx-lite/rate
* Follow Willosuna for free updates and new packs:
  https://willosuna.itch.io
* Every Willosuna pack + all future packs in one download:
  https://willosuna.itch.io/willosuna-all-in-one
========================================================================

Magic Spells VFX Lite v2.1
==========================

22 free pixel art spell effects, 64x64 per frame, transparent background.

WHAT'S NEW IN v2.1 (+5 effects)
  aura_fire, orb_ice, nova_void, meteor_fire and impact_void, a taste of the
  new void element and the new spell types of the full pack.

WHAT'S INSIDE
  6 core spells: cast, impact, fire_impact, ice_shatter, zap, heal
  impact in 10 more elements (elements/): ice, lightning, arcane, nature,
  poison, holy, shadow, water, blood and void
  aura, orb, nova and meteor samples (elements/)
  2 white versions (white/) to tint to any color in your engine

THE FULL PACK
  Magic Spells VFX has 340 animations: 30 core spells, 26 effects in
  11 elements (including aura, orb, nova, beam, meteor and vortex) and white
  versions of every spell.
  https://willosuna.itch.io/magic-spells-vfx

EACH EFFECT FOLDER
  <name>_sheet.png      horizontal sprite sheet, 64x64 frames, left to right
  frames/<name>_NN.png  the same frames as single PNG files

USING THEM
  Import with nearest-neighbour filtering and scale by whole numbers
  (2x, 3x, 4x) so the pixels stay crisp.

LICENSE
  Free for commercial use, royalty free, no attribution required. Reselling or
  redistributing the files as an asset pack is not permitted. Full terms in
  LICENSE.txt

CHANGELOG
  v2.1  +5 effects from the new void element and the new spell types.
  v2.0  impact in 9 elements and 2 white versions.
  v1.0  6 core spell effects.
