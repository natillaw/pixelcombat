PIXEL RPG UI KIT — 6 themes + 39 item icons
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- 6 themes: stone, wood, royal, scifi, candy, forest — 60 UI sprites per theme (360 total)
  panels (9-slice), large panel, dialog box with name tag, buttons (normal / hover / pressed),
  wide buttons, 10 icon buttons (close, check, plus, minus, arrows, menu, pause),
  HP / MP / XP / stamina bars (frame + 25/50/75/100% examples), inventory slots (normal / selected),
  checkbox, radio, slider, toggle, tabs (active / inactive), selection cursor
- shared/: bar fill strips (58x4) for your own fill logic, arrow and hand cursors
- icons_16px/: 39 hand-made 16x16 item icons (potions, weapons, armour, gems, coins, food, keys, hearts...)
- Every sprite at 1x and 4x (nearest neighbour). Per-theme atlas PNG + JSON (x, y, w, h).
- previews/: example RPG screen in each theme

■ 9-SLICE
- panel_*: 6 px borders on all sides
- dialog_*: 15 px top (includes name tag), 5 px sides/bottom
- button_*: 3 px left/right, 2 px top, 3 px bottom
Godot: NinePatchRect (patch margins as above). Unity: Sprite Editor → Border. GameMaker: nine-slice in Sprite editor.
Use Nearest / Point filtering and no compression.

■ LICENSE
- Commercial and non-commercial games, apps, videos and streams. Credit not required (appreciated).
- Edit and recolour freely.
- Do not resell or redistribute the files themselves as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
UI sprites are drawn procedurally by a program; icons are hand-authored pixel maps. No image-generation models were used.
The program was written with AI coding assistance and everything was reviewed and adjusted by the creator.

-----
日本語
・6テーマ×UI部品60種（計360）＋アイテムアイコン39種（16x16）。9スライス対応パネル、ボタン3状態、HP/MP/XPバー、インベントリ枠、チェックボックス等。
・1倍・4倍PNG、テーマ別アトラス＋JSON、サンプル画面付き。Godot / Unity / RPGツクール / ウディタ / GameMaker 等で使えます。
・商用OK・クレジット不要・改変OK。素材そのものの再配布・再販売、AI学習への利用は禁止。
・画像生成AIは不使用（プログラム描画＋手打ちドット。プログラム作成にAI補助を利用し、制作者が確認・調整）。
