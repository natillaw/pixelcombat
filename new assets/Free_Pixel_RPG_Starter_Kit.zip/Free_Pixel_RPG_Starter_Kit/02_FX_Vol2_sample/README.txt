PIXEL FX VOL.2 — ELEMENTAL, WEATHER & STATUS — 101 animated pixel-art effects
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- 101 effects = 21 effect types × colour sets
  Campfire / Torch Flame (loop), Rain Overlay (loop), Snowfall Overlay (loop), Falling Leaves / Petals (loop),
  Water Splash, Landing Dust, Footstep Puff, Meteor Strike, Tornado (loop), Wind Gust (loop), Level Up,
  Item Pickup Shine, Stun Stars (loop), Sleep Zzz (loop), Floating Hearts (loop), Laser Beam (loop),
  Barrier Shield (loop), Freeze Crystal, Drip / DoT status (loop), Black Hole (loop), Portal Rift (loop)
  Colour sets: fire, ice, thunder, arcane, poison, holy, shadow, water, nature, blood, smoke, gold, love, earth, wind, rain
- Rain / Snow / Leaves overlays tile horizontally: place several side by side to cover a screen.
- Works together with "Pixel Spell & Combat FX" (Vol.1): same 64x64 size, same palette style and 12 fps.
- spritesheets_64px/       horizontal strips, 64x64 per frame (file name ends with frame count, e.g. _8f)
- spritesheets_256px_4x/   same strips scaled 4x (nearest neighbour) for video / OBS / high-res UI
- frames_64px/             every frame as a separate PNG
- preview_gifs/            3x preview animations on a dark background (preview only)
- fx_index.json            id, name, frame count, loop flag, suggested fps (12) for every effect
All PNGs are RGBA with hard-edged pixels (no anti-aliasing), 5-colour palette ramp per colour set.

■ HOW TO USE
- Godot: Sprite2D → Texture = strip, Animation > Hframes = frame count; or AnimatedSprite2D → SpriteFrames → "Add frames from sprite sheet".
  Turn off filtering (Texture Filter: Nearest).
- Unity: Sprite Mode Multiple → Sprite Editor → Slice Grid by Cell Size 64x64. Filter Mode: Point, Compression: None.
- GameMaker / RPG Maker / Aseprite / others: import as a horizontal strip with 64x64 cells.
- Loop effects (marked loop:true) repeat seamlessly. One-shot effects play once.

■ LICENSE
- Use in commercial and non-commercial games, videos, streams and other projects. Credit not required (appreciated).
- You may edit, recolour and combine the effects.
- Do not resell or redistribute the asset files themselves (or lightly edited versions) as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
Every pixel is drawn procedurally by a program (fixed palettes, no image-generation models). The program was written with AI coding assistance and every effect was reviewed and adjusted by the creator.

-----
日本語
・ドット絵エフェクトVol.2 101種（21種類×カラー）：焚き火・雨・雪・落ち葉・水しぶき・着地の土煙・隕石・竜巻・風・レベルアップ・アイテム取得・気絶・睡眠・ハート・レーザー・バリア・凍結・毒/出血・ブラックホール・ポータル。Vol.1と同じ64x64・同じ色味で組み合わせて使えます。64x64のスプライトシート（横並び）、4倍拡大版、1コマずつのPNG、プレビューGIF、一覧JSON入り。
・Godot / Unity / RPGツクール / ゲームメーカー / 動画編集 / OBS で使えます（拡大時は補間なし=Nearest推奨）。
・商用利用OK、クレジット不要、改変OK。素材ファイルそのものの再配布・再販売、AI学習への利用は禁止。
・プログラムでドットを1つずつ描画して作っています（画像生成AIは不使用。プログラム作成にAIの補助を利用し、制作者が全エフェクトを確認・調整しています）。
