FREE PIXEL RPG STARTER KIT — Ishihara Asset Forge / どんぐりラボ
A free sampler of 6 pixel-art packs in one colour style:
22 animated effects (64x64), a UI theme set, forest + village tiles, and 12 skill icons.
Commercial use OK, no credit required. Do not resell/redistribute the files as an asset pack; no AI training.
Full packs: https://ishiharaworks.itch.io/pixel-game-asset-complete-bundle
日本語：ドット絵素材6本の無料お試しセットです。商用OK・クレジット不要。
