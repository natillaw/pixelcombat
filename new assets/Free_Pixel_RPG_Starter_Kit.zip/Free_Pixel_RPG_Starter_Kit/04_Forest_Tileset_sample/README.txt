PIXEL FOREST TILESET 16x16 — grass, paths, pond, cliffs & 21 props
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- 37 ground tiles: grass ×3, dirt ×2, stone path, bridge, cliff ×3, cave entrance,
  grass↔dirt edge set (13 pieces: 3x3 + 4 inner corners), grass↔water shore set (13 pieces)
- Animated water (4 frames)
- 21 props: oak / pine / autumn / sakura trees (32x32), big & small rocks, bush, flowers ×3, tall grass,
  mushrooms, stump, log, fences (horizontal, vertical, ends), sign, chest (closed / open)
- tileset_16px.png + tileset_64px_4x.png (one sheet) and tileset_index.json (x, y, w, h of every piece)
- tiles_16px/ and tiles_64px_4x/ : every piece as a separate PNG
- preview_sample_map.png : example map built only from this pack
All PNGs are RGBA with hard-edged pixels. Use Nearest / Point filtering.
Matches the colour style of "Pixel Spell & Combat FX", "Pixel FX Vol.2" and "Pixel RPG UI Kit".

■ HOW TO USE
- Godot: TileSet with 16x16 cells on tileset_16px.png; place props as Sprite2D or larger tiles.
- Unity: Sprite Mode Multiple → slice 16x16 (or use tileset_index.json for props). Filter: Point.
- RPG Maker / Tiled / GameMaker: import tileset_16px.png on a 16px grid (scale 3x for RPG Maker MZ's 48px).
- Edge sets: names end with position — lt/ct/rt, lm/cm/rm, lb/cb/rb, and in-1-1 etc. for inner corners.

■ LICENSE
- Commercial and non-commercial use OK, credit not required, edits OK.
- Do not resell or redistribute the files as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
Every pixel is drawn procedurally by a program (fixed palettes, no image-generation models). The program
was written with AI coding assistance and every tile was reviewed and adjusted by the creator.
-----
日本語
・16x16の森タイルセット：草・土・石畳・橋・崖・洞窟、草↔土／草↔水の境界セット（各13枚）、水アニメ4コマ、木4種・岩・茂み・花・柵・看板・宝箱など小物21種。
・1枚のタイルシート＋4倍版＋1枚ずつのPNG＋座標JSON＋サンプルマップ入り。
・商用OK・クレジット不要・改変OK。素材の再配布・再販売、AI学習への利用は禁止。
・プログラムでドットを描画（画像生成AI不使用。プログラム作成にAI補助を利用し、制作者が確認・調整）。
