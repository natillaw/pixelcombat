PIXEL SKILL ICONS 32x32 — framed RPG skill / ability icons
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- Framed 32x32 skill icons: slashes, cross slashes, impacts, hit sparks, explosions, shockwaves, magic circles,
  ground spikes, bubbles, vortexes, pillars, buff auras, campfire, tornado, level up, pickup, stun, sleep, hearts,
  barrier shield, freeze, black hole, portal — in many element colours (fire, ice, thunder, arcane, holy, shadow, ...)
- icons_32px/            every icon as PNG, grouped by type
- icons_128px_4x/        4x versions (nearest neighbour)
- icons_32px_disabled/   greyed-out versions for locked / cooldown / unavailable skills
- icon_sheet_32px.png (+4x) and icons_index.json (id, name, type, element, 16 columns)
Matches "Pixel Spell & Combat FX" and "Pixel FX Vol.2": each icon is drawn from the same effect, so the skill button
and the animation on screen look the same.

■ LICENSE
- Commercial and non-commercial use OK, credit not required, edits OK.
- Do not resell or redistribute the files as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
Every pixel is drawn procedurally by a program (fixed palettes, no image-generation models). The program
was written with AI coding assistance and every icon was reviewed and adjusted by the creator.
-----
日本語
・32x32の枠付きスキルアイコン（斬撃・爆発・魔法陣・竜巻・バリア・状態異常など、属性カラー違い）。
・4倍版、使用不可用のグレー版、一覧シート、JSON付き。
・ドット絵エフェクトVol.1／Vol.2と同じエフェクトから作っているので、スキルボタンと演出の見た目がそろいます。
・商用OK・クレジット不要・改変OK。素材の再配布・再販売、AI学習への利用は禁止。
・プログラムでドットを描画（画像生成AI不使用。プログラム作成にAI補助を利用し、制作者が確認・調整）。
