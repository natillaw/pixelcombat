PIXEL SPELL & COMBAT FX — 120 animated pixel-art effects
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- 120 effects = 19 effect types × colour sets
  Impact Burst, Hit Spark, Slash, Thrust, Cross Slash, Explosion, Shockwave, Magic Circle (loop),
  Lightning Strike, Rising Sparkles (loop), Orb Projectile (loop), Energy Bolt (loop), Smoke Puff,
  Ground Spikes, Bubbles (loop), Vortex (loop), Pillar, Buff Aura (loop), Warp
  Colour sets: fire, ice, thunder, arcane, poison, holy, shadow, steel, water, nature, blood, smoke
- spritesheets_64px/       horizontal strips, 64x64 per frame (file name ends with frame count, e.g. _8f)
- spritesheets_256px_4x/   same strips scaled 4x (nearest neighbour) for video / OBS / high-res UI
- frames_64px/             every frame as a separate PNG
- preview_gifs/            3x preview animations on a dark background (preview only)
- fx_index.json            id, name, frame count, loop flag, suggested fps (12) for every effect
All PNGs are RGBA with hard-edged pixels (no anti-aliasing), 5-colour palette ramp per colour set.

■ HOW TO USE
- Godot: Sprite2D → Texture = strip, Animation > Hframes = frame count; or AnimatedSprite2D → SpriteFrames → "Add frames from sprite sheet".
  Turn off filtering (Texture Filter: Nearest).
- Unity: Sprite Mode Multiple → Sprite Editor → Slice Grid by Cell Size 64x64. Filter Mode: Point, Compression: None.
- GameMaker / RPG Maker / Aseprite / others: import as a horizontal strip with 64x64 cells.
- Loop effects (marked loop:true) repeat seamlessly. One-shot effects play once.

■ LICENSE
- Use in commercial and non-commercial games, videos, streams and other projects. Credit not required (appreciated).
- You may edit, recolour and combine the effects.
- Do not resell or redistribute the asset files themselves (or lightly edited versions) as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
Every pixel is drawn procedurally by a program (fixed palettes, no image-generation models). The program was written with AI coding assistance and every effect was reviewed and adjusted by the creator.

-----
日本語
・ドット絵エフェクト120種（19種類×カラー）。64x64のスプライトシート（横並び）、4倍拡大版、1コマずつのPNG、プレビューGIF、一覧JSON入り。
・Godot / Unity / RPGツクール / ゲームメーカー / 動画編集 / OBS で使えます（拡大時は補間なし=Nearest推奨）。
・商用利用OK、クレジット不要、改変OK。素材ファイルそのものの再配布・再販売、AI学習への利用は禁止。
・プログラムでドットを1つずつ描画して作っています（画像生成AIは不使用。プログラム作成にAIの補助を利用し、制作者が全エフェクトを確認・調整しています）。
