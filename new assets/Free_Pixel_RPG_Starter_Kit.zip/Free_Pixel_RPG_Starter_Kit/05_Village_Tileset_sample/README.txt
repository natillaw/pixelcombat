PIXEL VILLAGE & INTERIOR TILESET 16x16 — houses, roofs, streets, rooms & 13 props
Ishihara Asset Forge / どんぐりラボ

■ CONTENTS
- 31 tiles: walls (plaster, wood, brick, stone), door, window (day / lit), red & blue roofs (left, centre, right, ridge),
  cobblestone street, floors (wood, stone, tatami), interior wall + wall top, stairs, carpet 9-slice set
- 13 props: bed, table, chair, bookshelf, fireplace, potted plant, barrel, crate, well, street lamp, clay pot, round rug, chimney
- tileset_16px.png + tileset_64px_4x.png and tileset_index.json (x, y, w, h of every piece)
- tiles_16px/ and tiles_64px_4x/ : every piece as a separate PNG
- preview_sample_map.png : example village street + room built only from this pack
All PNGs are RGBA with hard-edged pixels. Use Nearest / Point filtering.
Same 16px grid and colour style as "Pixel Forest Tileset 16x16" — place the village right next to the forest.

■ HOW TO USE
- Tiled / Godot / Unity / GameMaker: 16x16 grid on tileset_16px.png. Props larger than 16px use tileset_index.json.
- RPG Maker MZ: scale 3x (48px). Roofs: put the ridge (_t) row on top, then l / c / r below.

■ LICENSE
- Commercial and non-commercial use OK, credit not required, edits OK.
- Do not resell or redistribute the files as an asset pack, and do not use them as AI training data.

■ HOW IT WAS MADE
Every pixel is drawn procedurally by a program (fixed palettes, no image-generation models). The program
was written with AI coding assistance and every tile was reviewed and adjusted by the creator.
-----
日本語
・16x16の村＋室内タイルセット：壁4種・ドア・窓（昼／明かり）・赤と青の屋根・石畳・床3種（木・石・畳）・室内の壁・階段・じゅうたん9枚セット、小物13種（ベッド・テーブル・椅子・本棚・暖炉・観葉植物・樽・木箱・井戸・街灯・壺・ラグ・煙突）。
・「森のタイルセット」と同じ16pxグリッド・同じ色味。村を森のとなりにそのまま並べられます。
・商用OK・クレジット不要・改変OK。素材の再配布・再販売、AI学習への利用は禁止。
・プログラムでドットを描画（画像生成AI不使用。プログラム作成にAI補助を利用し、制作者が確認・調整）。
